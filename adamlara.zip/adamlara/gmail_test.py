import smtplib

gmail_user = 'engineeringpracticetest@gmail.com'  
gmail_password = 'chinchila746'

sent_from = gmail_user  
#to = ['me@gmail.com', 'bill@gmail.com']  
to = 'techynina@gmail.com'
subject = 'Important Message- Access Granted'  
body = 'Door lock opened for the authorized person\n\nRegards,\nDoor Security'

email_text = """\  
From: %s  
To: %s  
Subject: %s

%s
""" % (sent_from, ".".join(to), subject, body)

try:  
    server = smtplib.SMTP_SSL('smtp.gmail.com', 465)
    server.ehlo()
    server.login(gmail_user, gmail_password)
    server.sendmail(sent_from, to, email_text)
    server.close()

    print 'Email sent!'
except:  
    print 'Something went wrong...'